# Bot-HackaTec-Local-2024-Filtro

Este repositorio contiene el codigo para crear un bot de Telegram que sirve para saber si tienes cancer de pulmon

## Configuracion

1. Clona este repositorio.
2. Instalar las dependencias `pip install -r requirements.txt`
3. Crea un bot en Telegram a traves de BotFather y obtener el token.
4. Reemplazar 'TU_TOKEN_AQUI' EN 'main.py'con el token.
Ejecutar el bot usando `pyton main.py`

## Funcionalidades

-Responde a los comandos `/start` y `/help`
-